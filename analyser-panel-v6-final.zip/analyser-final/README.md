# Analyser Panel v6

Production-oriented Xray management panel built on the v5 codebase.

## Included
- Authentication with HttpOnly JWT cookie and login rate limiting
- Inbound/client CRUD, expiry and quota controls
- VLESS links and QR codes
- Xray config generation, validation, backup and apply
- Live telemetry and per-client usage
- Daily/monthly usage rollups
- Automatic expiry/quota lifecycle enforcement
- Alerts and optional webhook notifications
- Server metrics and health checks
- Xray backup listing/create/restore
- Client portal with rotatable private tokens
- Audit log

## Production environment
Set:
- `NODE_ENV=production`
- `JWT_SECRET` to a long random secret
- `ADMIN_PASSWORD` for the first admin account
- `PORT` (optional, default 3000)
- `DB_PATH` (optional)

Install and run:
```bash
npm install
NODE_ENV=production JWT_SECRET='replace-with-long-random-secret' ADMIN_PASSWORD='replace-with-strong-password' npm start
```

Put the panel behind HTTPS/reverse proxy in production. Keep the Xray API bound to localhost. Do not expose the admin panel or Xray API directly to the public internet.

## Xray telemetry
Set the Xray binary and API address under Settings. The generated config enables StatsService for client traffic accounting.
