# Analyser Panel v4

Security-hardened continuation of v3 with expanded client management.

## v4 changes
- HttpOnly SameSite authentication cookie; bearer token support remains for API compatibility.
- Login rate limiting (10 failed attempts per IP per 15 minutes).
- Production requires `JWT_SECRET`.
- Basic security headers and same-origin checks for API mutations.
- JSON body limit of 32 KB.
- Input validation for tags, hosts, ports, UUIDs, expiry and quota values.
- Admin password change requiring the current password and a 12+ character new password.
- Client bandwidth quota (`quota_bytes`) with quota filter and manual disable action.
- Client list now exposes latest sampled usage and quota status.
- Expired and quota-exceeded client controls.
- SQLite foreign keys enabled; deleting an inbound cascades to its clients and traffic samples.
- Existing Xray telemetry, VLESS QR/link generation, inbound CRUD, Xray config validation/apply and service controls remain.

## Run

Set strong secrets before first production start:

```bash
export NODE_ENV=production
export ADMIN_PASSWORD='use-a-long-unique-password'
export JWT_SECRET='use-a-long-random-secret-at-least-32-chars'
npm install
npm start
```

Open `http://SERVER_IP:3000` (or put it behind HTTPS/reverse proxy).

Default username is `admin`. If the database already exists, `ADMIN_PASSWORD` does not overwrite the existing password; use **Panel Settings → Change admin password**.

## Xray telemetry

Telemetry requires an Xray build exposing the API/stats query used by the project. Configure the local API address in Panel Settings. The generated configuration enables `StatsService`.

## Important operational note

Client quota and expiry controls change the panel/database state. After changing client enable/disable state, use **Apply config** so the Xray configuration reflects the new client list. Do not expose the Xray API port publicly.
