# Analyser Panel v5

Analyser is a Node.js/Express + SQLite administration panel for a server running Xray.

## v5 additions

- Server metrics: uptime, CPU cores/load, memory and disk statistics.
- 24-hour traffic history endpoint and lightweight dashboard chart.
- Client portal with a revocable/rotatable private token.
- Per-client portal page with VLESS link, QR code, expiry and sampled usage.
- Audit log for client create/update/toggle/delete and portal-token rotation.
- Responsive mobile UI.
- Existing v4 authentication, client/inbound CRUD, quotas, telemetry and Xray config validation retained.

## Requirements

- Node.js 20+ recommended
- Xray installed on the server if Xray management/telemetry is required
- systemd if using the built-in Xray restart/status buttons

## Install

```bash
npm install
```

## Production environment

Set at least:

```bash
export NODE_ENV=production
export JWT_SECRET='use-a-long-random-secret'
export ADMIN_PASSWORD='use-a-strong-password'
```

Optional:

```bash
export PORT=3000
export DB_PATH=/var/lib/analyser/analyser.db
```

Start:

```bash
npm start
```

## Xray

Configure the Xray binary, config path, server host and Stats API address under Panel Settings. The generated config enables `StatsService` and user traffic counters. Always validate a generated config before applying it.

## Client portal

From Clients, choose **Portal**. The panel generates a private token URL. Anyone who has that URL can see that client's connection information and usage, so treat it like a password. Rotating the portal token immediately invalidates the old URL.

## Security notes

- Use HTTPS/reverse proxy in production.
- Do not expose the Xray Stats API publicly.
- Use a strong admin password and JWT secret.
- Keep client portal URLs private.
- Review the Audit page periodically.
