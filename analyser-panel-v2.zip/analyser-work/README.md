# Analyser Panel

A self-hosted Node.js/Express management panel for an Xray server.

## Included
- JWT login with SQLite-backed users
- Dashboard counters
- Inbound CRUD: create, edit, enable/disable, delete
- Client CRUD: create, edit, enable/disable, delete
- Client UUID generation and VLESS URI/QR generation
- Client expiry and flow fields
- Xray configuration generation, backup, validation, and apply
- Xray service status/restart tools
- Server host and Xray config path settings

## Run
1. Install Node.js 20+.
2. Extract the project.
3. Run `npm install`.
4. Set a strong `ADMIN_PASSWORD` and `JWT_SECRET` environment variable.
5. Run `npm start`.
6. Open `http://SERVER_IP:3000`.

Default username is `admin`. If `ADMIN_PASSWORD` is not set on the first run, the temporary password is `change-me-now`; change it before exposing the panel.

## Xray
The panel expects an `xray` executable in PATH and a systemd service named `xray` for the service tools. Set the config path in Panel Settings. The Apply operation backs up an existing config, writes the generated config, then runs Xray's config test before reporting success.

Before using Apply on a production server, verify your Xray version and generated transport/TLS requirements. Keep a tested backup of your existing configuration.
