# Analyser Panel

A starter real server-management panel with login, SQLite persistence, inbounds, clients, VLESS link/QR generation, settings, and Xray service tools.

## Run

1. Install Node.js 20+.
2. `npm install`
3. Set a strong `ADMIN_PASSWORD` and `JWT_SECRET` environment variable.
4. `npm start`
5. Open `http://SERVER_IP:3000`

Default username: `admin`. The password is `ADMIN_PASSWORD`; if omitted, the app uses `change-me-now` for first boot, so set it before production use.

## Important

This version stores the panel data in SQLite and generates client VLESS URIs from the stored inbound/client records. It does **not** automatically rewrite an Xray configuration yet. The Xray restart/check endpoints operate on the local machine and therefore should only be exposed behind proper authentication/firewall controls.
