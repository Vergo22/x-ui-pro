import express from 'express';
import Database from 'better-sqlite3';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import QRCode from 'qrcode';
import { v4 as uuidv4 } from 'uuid';
import crypto from 'crypto';
import fs from 'fs';
import { execFile } from 'child_process';
import path from 'path';

const app=express(); const PORT=process.env.PORT||3000;
const SECRET=process.env.JWT_SECRET||crypto.randomBytes(32).toString('hex');
const db=new Database(process.env.DB_PATH||'analyser.db');
db.pragma('journal_mode=WAL');
db.exec(`CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY,username TEXT UNIQUE,password TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS settings(key TEXT PRIMARY KEY,value TEXT);
CREATE TABLE IF NOT EXISTS inbounds(id INTEGER PRIMARY KEY AUTOINCREMENT,tag TEXT UNIQUE,protocol TEXT DEFAULT 'vless',port INTEGER,network TEXT DEFAULT 'tcp',security TEXT DEFAULT 'none',sni TEXT DEFAULT '',enabled INTEGER DEFAULT 1,created_at TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS clients(id INTEGER PRIMARY KEY AUTOINCREMENT,inbound_id INTEGER,name TEXT,uuid TEXT UNIQUE,flow TEXT DEFAULT '',email TEXT DEFAULT '',expiry INTEGER DEFAULT 0,enabled INTEGER DEFAULT 1,created_at TEXT DEFAULT CURRENT_TIMESTAMP,FOREIGN KEY(inbound_id) REFERENCES inbounds(id) ON DELETE CASCADE);
CREATE TABLE IF NOT EXISTS traffic_samples(id INTEGER PRIMARY KEY AUTOINCREMENT,client_id INTEGER,ts INTEGER,up_bytes INTEGER DEFAULT 0,down_bytes INTEGER DEFAULT 0,online INTEGER DEFAULT 0,FOREIGN KEY(client_id) REFERENCES clients(id) ON DELETE CASCADE);
CREATE INDEX IF NOT EXISTS idx_traffic_client_ts ON traffic_samples(client_id,ts);`);
if(!db.prepare('SELECT 1 FROM users LIMIT 1').get()) db.prepare('INSERT INTO users(username,password) VALUES(?,?)').run('admin',bcrypt.hashSync(process.env.ADMIN_PASSWORD||'change-me-now',12));
const setting=(k,d='')=>db.prepare('SELECT value FROM settings WHERE key=?').get(k)?.value??d;
const auth=(req,res,next)=>{try{const h=req.headers.authorization||''; if(!h.startsWith('Bearer ')) throw 0; req.user=jwt.verify(h.slice(7),SECRET); next()}catch{res.status(401).json({error:'Unauthorized'})}};
app.use(express.json()); app.use(express.static('public'));
app.post('/api/login',(req,res)=>{const u=db.prepare('SELECT * FROM users WHERE username=?').get(req.body.username); if(!u||!bcrypt.compareSync(req.body.password,u.password)) return res.status(401).json({error:'Invalid credentials'}); res.json({token:jwt.sign({id:u.id,username:u.username},SECRET,{expiresIn:'12h'})})});
app.get('/api/me',auth,(req,res)=>res.json(req.user));
app.get('/api/dashboard',auth,(req,res)=>{const now=Math.floor(Date.now()/1000);res.json({inbounds:db.prepare('SELECT COUNT(*) n FROM inbounds WHERE enabled=1').get().n,clients:db.prepare('SELECT COUNT(*) n FROM clients WHERE enabled=1').get().n,expired:db.prepare('SELECT COUNT(*) n FROM clients WHERE enabled=1 AND expiry>0 AND expiry<?').get(now).n,disabled:db.prepare('SELECT COUNT(*) n FROM clients WHERE enabled=0').get().n,serverTime:new Date().toISOString()})});
app.get('/api/inbounds',auth,(req,res)=>res.json(db.prepare('SELECT * FROM inbounds ORDER BY id DESC').all()));
app.post('/api/inbounds',auth,(req,res)=>{const b=req.body; if(!b.tag||!b.port) return res.status(400).json({error:'tag and port required'}); const port=Number(b.port); if(!Number.isInteger(port)||port<1||port>65535)return res.status(400).json({error:'invalid port'}); try{const r=db.prepare('INSERT INTO inbounds(tag,protocol,port,network,security,sni,enabled) VALUES(?,?,?,?,?,?,?)').run(String(b.tag).trim(),b.protocol||'vless',port,b.network||'tcp',b.security||'none',b.sni||'',b.enabled===false?0:1); res.json({id:r.lastInsertRowid})}catch(e){res.status(400).json({error:e.message})}});
app.put('/api/inbounds/:id',auth,(req,res)=>{const b=req.body; const old=db.prepare('SELECT * FROM inbounds WHERE id=?').get(req.params.id); if(!old)return res.status(404).json({error:'Inbound not found'}); const port=Number(b.port??old.port); if(!Number.isInteger(port)||port<1||port>65535)return res.status(400).json({error:'invalid port'}); try{db.prepare('UPDATE inbounds SET tag=?,protocol=?,port=?,network=?,security=?,sni=?,enabled=? WHERE id=?').run(String(b.tag??old.tag).trim(),b.protocol??old.protocol,port,b.network??old.network,b.security??old.security,b.sni??old.sni,b.enabled===false?0:(b.enabled===true?1:old.enabled),req.params.id);res.json({ok:true})}catch(e){res.status(400).json({error:e.message})}});
app.patch('/api/inbounds/:id/toggle',auth,(req,res)=>{const r=db.prepare('UPDATE inbounds SET enabled=CASE enabled WHEN 1 THEN 0 ELSE 1 END WHERE id=?').run(req.params.id);if(!r.changes)return res.status(404).json({error:'Inbound not found'});res.json({ok:true})});
app.delete('/api/inbounds/:id',auth,(req,res)=>{db.prepare('DELETE FROM clients WHERE inbound_id=?').run(req.params.id); db.prepare('DELETE FROM inbounds WHERE id=?').run(req.params.id); res.json({ok:true})});
app.get('/api/clients',auth,(req,res)=>{const q=String(req.query.q||'').trim();const status=req.query.status;let sql='SELECT c.*,i.tag inbound_tag,i.port,i.network,i.security,i.sni FROM clients c JOIN inbounds i ON i.id=c.inbound_id WHERE 1=1';const args=[];if(q){sql+=' AND (c.name LIKE ? OR c.email LIKE ? OR c.uuid LIKE ? OR i.tag LIKE ?)';const z='%'+q+'%';args.push(z,z,z,z)}if(status==='enabled')sql+=' AND c.enabled=1';if(status==='disabled')sql+=' AND c.enabled=0';if(status==='expired'){sql+=' AND c.expiry>0 AND c.expiry<?';args.push(Math.floor(Date.now()/1000))}sql+=' ORDER BY c.id DESC';res.json(db.prepare(sql).all(...args))});
app.post('/api/clients',auth,async(req,res)=>{const b=req.body; if(!b.inbound_id||!b.name) return res.status(400).json({error:'inbound_id and name required'}); const ib=db.prepare('SELECT id FROM inbounds WHERE id=?').get(b.inbound_id);if(!ib)return res.status(400).json({error:'Inbound not found'}); const uuid=b.uuid||uuidv4(); const expiry=Number(b.expiry||0);if(!Number.isFinite(expiry)||expiry<0)return res.status(400).json({error:'invalid expiry'}); try{const r=db.prepare('INSERT INTO clients(inbound_id,name,uuid,flow,email,expiry,enabled) VALUES(?,?,?,?,?,?,?)').run(b.inbound_id,String(b.name).trim(),uuid,b.flow||'',b.email||'',expiry,b.enabled===false?0:1); res.json({id:r.lastInsertRowid,uuid})}catch(e){res.status(400).json({error:e.message})}});
app.put('/api/clients/:id',auth,(req,res)=>{const b=req.body;const old=db.prepare('SELECT * FROM clients WHERE id=?').get(req.params.id);if(!old)return res.status(404).json({error:'Client not found'});const inboundId=Number(b.inbound_id??old.inbound_id);if(!db.prepare('SELECT id FROM inbounds WHERE id=?').get(inboundId))return res.status(400).json({error:'Inbound not found'});const expiry=Number(b.expiry??old.expiry);if(!Number.isFinite(expiry)||expiry<0)return res.status(400).json({error:'invalid expiry'});try{db.prepare('UPDATE clients SET inbound_id=?,name=?,uuid=?,flow=?,email=?,expiry=?,enabled=? WHERE id=?').run(inboundId,String(b.name??old.name).trim(),b.uuid??old.uuid,b.flow??old.flow,b.email??old.email,expiry,b.enabled===false?0:(b.enabled===true?1:old.enabled),req.params.id);res.json({ok:true})}catch(e){res.status(400).json({error:e.message})}});
app.patch('/api/clients/:id/toggle',auth,(req,res)=>{const r=db.prepare('UPDATE clients SET enabled=CASE enabled WHEN 1 THEN 0 ELSE 1 END WHERE id=?').run(req.params.id);if(!r.changes)return res.status(404).json({error:'Client not found'});res.json({ok:true})});
app.delete('/api/clients/:id',auth,(req,res)=>{db.prepare('DELETE FROM clients WHERE id=?').run(req.params.id);res.json({ok:true})});
app.post('/api/clients/disable-expired',auth,(req,res)=>{const now=Math.floor(Date.now()/1000);const r=db.prepare('UPDATE clients SET enabled=0 WHERE expiry>0 AND expiry<? AND enabled=1').run(now);res.json({ok:true,disabled:r.changes})});
app.post('/api/clients/:id/vless',auth,async(req,res)=>{const c=db.prepare('SELECT c.*,i.* FROM clients c JOIN inbounds i ON i.id=c.inbound_id WHERE c.id=?').get(req.params.id); if(!c)return res.status(404).json({error:'Client not found'}); const host=req.body.host||setting('server_host','localhost'); const params=new URLSearchParams(); params.set('encryption','none'); if(c.flow)params.set('flow',c.flow); const security=c.security||'none'; if(security==='tls'){params.set('security','tls');if(c.sni||c.sni)params.set('sni',c.sni||host)} else params.set('security',security); if(c.network&&c.network!=='tcp')params.set('type',c.network); const link=`vless://${c.uuid}@${host}:${c.port}?${params.toString()}#${encodeURIComponent(c.name)}`; const qr=await QRCode.toDataURL(link); res.json({link,qr})});
app.get('/api/settings',auth,(req,res)=>res.json({server_host:setting('server_host',''),xray_config:setting('xray_config','/etc/xray/config.json'),xray_binary:setting('xray_binary','xray'),xray_api:setting('xray_api','127.0.0.1:10085')}));
app.put('/api/settings',auth,(req,res)=>{for(const [k,v] of Object.entries(req.body)){if(['server_host','xray_config','xray_binary','xray_api'].includes(k))db.prepare('INSERT INTO settings(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value').run(k,String(v))}res.json({ok:true})});

const xrayBinary=()=>setting('xray_binary','xray');
const xrayApiServer=()=>setting('xray_api','127.0.0.1:10085');
function runXrayStats(){
  return new Promise((resolve,reject)=>{
    execFile(xrayBinary(),['api','statsquery','--server='+xrayApiServer()],{timeout:7000,maxBuffer:4*1024*1024},(err,stdout,stderr)=>{
      if(err) return reject(new Error((stderr||err.message||'Xray stats query failed').trim()));
      let raw=String(stdout||'').trim();
      try{ return resolve(JSON.parse(raw)); }catch{}
      const start=raw.indexOf('{'), end=raw.lastIndexOf('}');
      if(start>=0&&end>start){try{return resolve(JSON.parse(raw.slice(start,end+1)))}catch{}}
      reject(new Error('Xray stats output was not JSON'));
    });
  });
}
function extractStats(payload){
  const arr=Array.isArray(payload?.stat)?payload.stat:Array.isArray(payload?.stats)?payload.stats:[];
  const out=new Map();
  for(const st of arr){
    const name=String(st?.name||''); const value=Number(st?.value||0); if(!name) continue;
    const m=name.match(/^user>>>([^>]+)>>>traffic>>>(uplink|downlink)$/i);
    if(m){const key=m[1]; const dir=m[2].toLowerCase(); const row=out.get(key)||{up:0,down:0}; row[dir==='uplink'?'up':'down']=Number.isFinite(value)?value:0; out.set(key,row)}
  }
  return out;
}
async function collectTraffic(){
  const clients=db.prepare('SELECT id,name,email,uuid,enabled,expiry FROM clients').all();
  let stats; try{stats=extractStats(await runXrayStats())}catch(e){return {available:false,error:e.message,clients:[]};}
  const now=Math.floor(Date.now()/1000), rows=[];
  const insert=db.prepare('INSERT INTO traffic_samples(client_id,ts,up_bytes,down_bytes,online) VALUES(?,?,?,?,?)');
  const tx=db.transaction(()=>{for(const c of clients){const key=c.email||c.name; const v=stats.get(key)||{up:0,down:0}; const prev=db.prepare('SELECT up_bytes,down_bytes,ts FROM traffic_samples WHERE client_id=? ORDER BY ts DESC LIMIT 1').get(c.id); const active=!!prev && ((v.up>prev.up_bytes)||(v.down>prev.down_bytes)) && now-prev.ts<=180; insert.run(c.id,now,v.up,v.down,active?1:0); rows.push({id:c.id,name:c.name,email:c.email,up_bytes:v.up,down_bytes:v.down,online:active,expiry:c.expiry,enabled:c.enabled});}}); tx();
  return {available:true,serverTime:new Date().toISOString(),clients:rows};
}
app.get('/api/traffic',auth,async(req,res)=>{try{const j=await collectTraffic(); if(j.available){const since=Math.floor(Date.now()/1000)-86400; const history=db.prepare(`SELECT ts,SUM(up_bytes) up_bytes,SUM(down_bytes) down_bytes,SUM(online) online FROM traffic_samples WHERE ts>=? GROUP BY ts ORDER BY ts`).all(since); j.history=history;} res.json(j)}catch(e){res.status(500).json({available:false,error:e.message})}});
app.get('/api/clients/:id/traffic',auth,(req,res)=>{const id=Number(req.params.id);const c=db.prepare('SELECT id,name,email FROM clients WHERE id=?').get(id);if(!c)return res.status(404).json({error:'Client not found'});const since=Math.floor(Date.now()/1000)-7*86400;const history=db.prepare('SELECT ts,up_bytes,down_bytes,online FROM traffic_samples WHERE client_id=? AND ts>=? ORDER BY ts').all(id,since);res.json({client:c,history})});
function buildXrayConfig(){
  const inbounds=db.prepare('SELECT * FROM inbounds WHERE enabled=1 ORDER BY id').all();
  return {
    log:{loglevel:'warning'},
    api:{services:['StatsService'],tag:'api'},
    stats:{},
    policy:{levels:{0:{statsUserUplink:true,statsUserDownlink:true}},system:{statsInboundUplink:true,statsInboundDownlink:true}},
    inbounds:[{tag:'api',listen:'127.0.0.1',port:10085,protocol:'dokodemo-door',settings:{address:'127.0.0.1'},},...inbounds.map(i=>({
      tag:i.tag, port:Number(i.port), listen:'0.0.0.0', protocol:i.protocol,
      settings:{clients:db.prepare('SELECT uuid,email,name,flow FROM clients WHERE inbound_id=? AND enabled=1').all(i.id).map(c=>({id:c.uuid,email:c.email||c.name,flow:c.flow||undefined})).map(x=>{Object.keys(x).forEach(k=>x[k]===undefined&&delete x[k]);return x}),decryption:i.protocol==='vless'?'none':undefined},
      streamSettings:{network:i.network||'tcp',security:i.security||'none',...(i.security==='tls'&&i.sni?{tlsSettings:{serverName:i.sni}}:{})}
    })),],
    routing:{rules:[{type:'field',inboundTag:['api'],outboundTag:'api'}]},
    outbounds:[{protocol:'freedom',tag:'direct'},{protocol:'blackhole',tag:'blocked'},{protocol:'blackhole',tag:'api'}]
  };
}
app.get('/api/xray/config',auth,(req,res)=>res.json(buildXrayConfig()));
app.post('/api/xray/apply',auth,(req,res)=>{
  const cfgPath=setting('xray_config','/etc/xray/config.json');
  try{
    const cfg=buildXrayConfig(); const dir=path.dirname(cfgPath); fs.mkdirSync(dir,{recursive:true});
    if(fs.existsSync(cfgPath)) fs.copyFileSync(cfgPath,cfgPath+'.bak-'+Date.now());
    const tmp=cfgPath+'.tmp'; fs.writeFileSync(tmp,JSON.stringify(cfg,null,2));
    execFile(xrayBinary(),['run','-test','-config',tmp],{timeout:10000},(e,stdout,stderr)=>{
      if(e) return res.status(400).json({error:'Xray config test failed',details:(stderr||stdout||e.message).trim()});
      fs.renameSync(tmp,cfgPath); res.json({ok:true,path:cfgPath});
    });
  }catch(e){res.status(500).json({error:e.message})}
});

app.post('/api/tools/restart-xray',auth,(req,res)=>{execFile('systemctl',['restart','xray'],{timeout:15000},e=>e?res.status(500).json({error:e.message}):res.json({ok:true}))});
app.post('/api/tools/test-xray',auth,(req,res)=>{execFile('systemctl',['is-active','xray'],{timeout:5000},(e,stdout)=>res.json({active:!e&&stdout.trim()==='active',status:stdout.trim()||'unknown'}))});
app.listen(PORT,()=>console.log(`Analyser Panel listening on :${PORT}`));
