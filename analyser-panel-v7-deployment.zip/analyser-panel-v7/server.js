import express from 'express';
import Database from 'better-sqlite3';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import QRCode from 'qrcode';
import { v4 as uuidv4, validate as uuidValidate } from 'uuid';
import crypto from 'crypto';
import fs from 'fs';
import { execFile } from 'child_process';
import path from 'path';
import os from 'os';

const app = express();
app.set('trust proxy', 1);
const PORT = Number(process.env.PORT || 3000);
const isProd = process.env.NODE_ENV === 'production';
const SECRET = process.env.JWT_SECRET || (isProd ? '' : crypto.randomBytes(32).toString('hex'));
if (!SECRET) throw new Error('JWT_SECRET is required when NODE_ENV=production');
if (isProd && !process.env.ADMIN_PASSWORD) console.warn('WARNING: ADMIN_PASSWORD is not set; existing database credentials will be used.');

const db = new Database(process.env.DB_PATH || 'analyser.db');
db.pragma('journal_mode=WAL');
db.pragma('foreign_keys=ON');
db.exec(`
CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY,username TEXT UNIQUE,password TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS settings(key TEXT PRIMARY KEY,value TEXT);
CREATE TABLE IF NOT EXISTS inbounds(id INTEGER PRIMARY KEY AUTOINCREMENT,tag TEXT UNIQUE,protocol TEXT DEFAULT 'vless',port INTEGER,network TEXT DEFAULT 'tcp',security TEXT DEFAULT 'none',sni TEXT DEFAULT '',enabled INTEGER DEFAULT 1,created_at TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS clients(id INTEGER PRIMARY KEY AUTOINCREMENT,inbound_id INTEGER,name TEXT,uuid TEXT UNIQUE,flow TEXT DEFAULT '',email TEXT DEFAULT '',expiry INTEGER DEFAULT 0,quota_bytes INTEGER DEFAULT 0,enabled INTEGER DEFAULT 1,created_at TEXT DEFAULT CURRENT_TIMESTAMP,FOREIGN KEY(inbound_id) REFERENCES inbounds(id) ON DELETE CASCADE);
CREATE TABLE IF NOT EXISTS traffic_samples(id INTEGER PRIMARY KEY AUTOINCREMENT,client_id INTEGER,ts INTEGER,up_bytes INTEGER DEFAULT 0,down_bytes INTEGER DEFAULT 0,online INTEGER DEFAULT 0,FOREIGN KEY(client_id) REFERENCES clients(id) ON DELETE CASCADE);
CREATE TABLE IF NOT EXISTS audit_log(id INTEGER PRIMARY KEY AUTOINCREMENT,user_id INTEGER,action TEXT,details TEXT,ts INTEGER);
CREATE INDEX IF NOT EXISTS idx_audit_ts ON audit_log(ts);
CREATE INDEX IF NOT EXISTS idx_traffic_client_ts ON traffic_samples(client_id,ts);
CREATE TABLE IF NOT EXISTS usage_daily(client_id INTEGER, day TEXT, up_bytes INTEGER DEFAULT 0, down_bytes INTEGER DEFAULT 0, PRIMARY KEY(client_id,day), FOREIGN KEY(client_id) REFERENCES clients(id) ON DELETE CASCADE);
CREATE TABLE IF NOT EXISTS usage_monthly(client_id INTEGER, month TEXT, up_bytes INTEGER DEFAULT 0, down_bytes INTEGER DEFAULT 0, PRIMARY KEY(client_id,month), FOREIGN KEY(client_id) REFERENCES clients(id) ON DELETE CASCADE);
CREATE TABLE IF NOT EXISTS alerts(id INTEGER PRIMARY KEY AUTOINCREMENT, kind TEXT NOT NULL, client_id INTEGER, message TEXT NOT NULL, created_at INTEGER NOT NULL, acknowledged INTEGER DEFAULT 0, FOREIGN KEY(client_id) REFERENCES clients(id) ON DELETE CASCADE);
CREATE INDEX IF NOT EXISTS idx_alerts_created ON alerts(created_at);

`);
try { db.exec('ALTER TABLE clients ADD COLUMN quota_bytes INTEGER DEFAULT 0'); } catch {}
try { db.exec('ALTER TABLE clients ADD COLUMN portal_token TEXT'); } catch {}
try { db.exec('CREATE UNIQUE INDEX IF NOT EXISTS idx_clients_portal_token ON clients(portal_token) WHERE portal_token IS NOT NULL'); } catch {}
if (!db.prepare('SELECT 1 FROM users LIMIT 1').get()) {
  const password = process.env.ADMIN_PASSWORD || 'change-me-now';
  db.prepare('INSERT INTO users(username,password) VALUES(?,?)').run('admin', bcrypt.hashSync(password, 12));
  if (!process.env.ADMIN_PASSWORD) console.warn('WARNING: default admin password created. Set ADMIN_PASSWORD and change it immediately in Panel Settings.');
}

const setting = (k, d = '') => db.prepare('SELECT value FROM settings WHERE key=?').get(k)?.value ?? d;
function audit(req, action, details='') { try { db.prepare('INSERT INTO audit_log(user_id,action,details,ts) VALUES(?,?,?,?)').run(req.user?.id || null, action, String(details).slice(0,500), Math.floor(Date.now()/1000)); } catch {} }
function newPortalToken(){ return crypto.randomBytes(24).toString('base64url'); }
const clientIp = req => String(req.headers['x-forwarded-for'] || req.socket.remoteAddress || '').split(',')[0].trim();
const loginAttempts = new Map();
function rateLimitLogin(req, res, next) {
  const key = clientIp(req); const now = Date.now(); const v = loginAttempts.get(key) || { count: 0, reset: now + 15 * 60_000 };
  if (now > v.reset) { v.count = 0; v.reset = now + 15 * 60_000; }
  if (v.count >= 10) return res.status(429).json({ error: 'Too many login attempts. Try again later.' });
  req.loginRate = v; next();
}
function finishLogin(req, ok) {
  const v = req.loginRate; if (!v) return;
  if (ok) loginAttempts.delete(clientIp(req)); else { v.count++; loginAttempts.set(clientIp(req), v); }
}
function cookieOpts() { return `HttpOnly; Path=/; SameSite=Lax${isProd ? '; Secure' : ''}`; }
function tokenFrom(req) {
  const h = req.headers.authorization || '';
  if (h.startsWith('Bearer ')) return h.slice(7);
  const m = String(req.headers.cookie || '').match(/(?:^|; )analyser_token=([^;]+)/);
  return m ? decodeURIComponent(m[1]) : '';
}
function auth(req, res, next) {
  try { req.user = jwt.verify(tokenFrom(req), SECRET); next(); }
  catch { res.status(401).json({ error: 'Unauthorized' }); }
}
function validateText(v, name, max = 120, required = false) {
  if (v === undefined || v === null) { if (required) throw new Error(`${name} is required`); return ''; }
  const s = String(v).trim(); if (required && !s) throw new Error(`${name} is required`); if (s.length > max) throw new Error(`${name} is too long`); return s;
}
function positiveInt(v, name, min, max, fallback) {
  if (v === undefined || v === null || v === '') return fallback;
  const n = Number(v); if (!Number.isInteger(n) || n < min || n > max) throw new Error(`invalid ${name}`); return n;
}
function safeOrigin(req) {
  const origin = req.headers.origin; if (!origin) return true;
  try { return new URL(origin).host === req.headers.host; } catch { return false; }
}

app.disable('x-powered-by');
app.get('/healthz', (req, res) => res.status(200).json({ ok: true, service: 'analyser-panel', version: '7.0.0', time: new Date().toISOString() }));
app.get('/api/version', auth, (req, res) => res.json({ version: '7.0.0', node: process.version, environment: isProd ? 'production' : 'development' }));
app.use((req, res, next) => {
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('X-Frame-Options', 'DENY');
  res.setHeader('Referrer-Policy', 'same-origin');
  if (isProd) res.setHeader('Strict-Transport-Security', 'max-age=15552000; includeSubDomains');
  if (['POST','PUT','PATCH','DELETE'].includes(req.method) && req.path.startsWith('/api/') && !safeOrigin(req)) return res.status(403).json({ error: 'Invalid request origin' });
  next();
});
app.use(express.json({ limit: '32kb' }));
app.use(express.static('public', { extensions: ['html'] }));

app.post('/api/login', rateLimitLogin, (req, res) => {
  const username = validateText(req.body?.username, 'username', 80, true);
  const password = String(req.body?.password || '');
  const u = db.prepare('SELECT * FROM users WHERE username=?').get(username);
  const ok = !!u && password.length <= 200 && bcrypt.compareSync(password, u.password);
  finishLogin(req, ok);
  if (!ok) return res.status(401).json({ error: 'Invalid credentials' });
  const token = jwt.sign({ id: u.id, username: u.username }, SECRET, { expiresIn: '12h' });
  res.setHeader('Set-Cookie', `analyser_token=${encodeURIComponent(token)}; ${cookieOpts()}`);
  res.json({ ok: true, user: { id: u.id, username: u.username } });
});
app.post('/api/logout', (req, res) => { res.setHeader('Set-Cookie', `analyser_token=; Max-Age=0; ${cookieOpts()}`); res.json({ ok: true }); });
app.get('/api/me', auth, (req, res) => res.json(req.user));
app.put('/api/me/password', auth, (req, res) => {
  const current = String(req.body?.currentPassword || ''), next = String(req.body?.newPassword || '');
  if (next.length < 12 || next.length > 200) return res.status(400).json({ error: 'New password must be 12-200 characters' });
  const u = db.prepare('SELECT * FROM users WHERE id=?').get(req.user.id);
  if (!u || !bcrypt.compareSync(current, u.password)) return res.status(400).json({ error: 'Current password is incorrect' });
  db.prepare('UPDATE users SET password=? WHERE id=?').run(bcrypt.hashSync(next, 12), u.id);
  res.setHeader('Set-Cookie', `analyser_token=; Max-Age=0; ${cookieOpts()}`);
  res.json({ ok: true, message: 'Password changed. Please sign in again.' });
});

app.get('/api/dashboard', auth, (req, res) => {
  const now = Math.floor(Date.now()/1000);
  const total = db.prepare('SELECT COUNT(*) n FROM clients').get().n;
  res.json({
    inbounds: db.prepare('SELECT COUNT(*) n FROM inbounds WHERE enabled=1').get().n,
    clients: db.prepare('SELECT COUNT(*) n FROM clients WHERE enabled=1').get().n,
    totalClients: total,
    expired: db.prepare('SELECT COUNT(*) n FROM clients WHERE enabled=1 AND expiry>0 AND expiry<?').get(now).n,
    quotaExceeded: db.prepare(`SELECT COUNT(*) n FROM clients c WHERE c.enabled=1 AND c.quota_bytes>0 AND EXISTS (SELECT 1 FROM traffic_samples t WHERE t.client_id=c.id AND (t.up_bytes+t.down_bytes)>=c.quota_bytes)`).get().n,
    disabled: db.prepare('SELECT COUNT(*) n FROM clients WHERE enabled=0').get().n,
    serverTime: new Date().toISOString()
  });
});

app.get('/api/inbounds', auth, (req,res)=>res.json(db.prepare('SELECT * FROM inbounds ORDER BY id DESC').all()));
app.post('/api/inbounds', auth, (req,res)=>{
  try {
    const b=req.body||{}, tag=validateText(b.tag,'tag',80,true), port=positiveInt(b.port,'port',1,65535,443);
    const protocol=['vless','trojan'].includes(b.protocol)?b.protocol:'vless', network=['tcp','ws','grpc'].includes(b.network)?b.network:'tcp', security=['none','tls'].includes(b.security)?b.security:'none', sni=validateText(b.sni,'sni',255);
    const r=db.prepare('INSERT INTO inbounds(tag,protocol,port,network,security,sni,enabled) VALUES(?,?,?,?,?,?,?)').run(tag,protocol,port,network,security,sni,b.enabled===false?0:1); res.json({id:r.lastInsertRowid});
  } catch(e) { res.status(400).json({error:e.message}); }
});
app.put('/api/inbounds/:id', auth, (req,res)=>{
  try { const old=db.prepare('SELECT * FROM inbounds WHERE id=?').get(req.params.id); if(!old)return res.status(404).json({error:'Inbound not found'}); const b=req.body||{};
    const tag=validateText(b.tag??old.tag,'tag',80,true), port=positiveInt(b.port,'port',1,65535,old.port), protocol=['vless','trojan'].includes(b.protocol??old.protocol)?(b.protocol??old.protocol):old.protocol, network=['tcp','ws','grpc'].includes(b.network??old.network)?(b.network??old.network):old.network, security=['none','tls'].includes(b.security??old.security)?(b.security??old.security):old.security, sni=validateText(b.sni??old.sni,'sni',255);
    db.prepare('UPDATE inbounds SET tag=?,protocol=?,port=?,network=?,security=?,sni=?,enabled=? WHERE id=?').run(tag,protocol,port,network,security,sni,b.enabled===false?0:(b.enabled===true?1:old.enabled),req.params.id); res.json({ok:true});
  } catch(e){res.status(400).json({error:e.message});}
});
app.patch('/api/inbounds/:id/toggle',auth,(req,res)=>{const r=db.prepare('UPDATE inbounds SET enabled=CASE enabled WHEN 1 THEN 0 ELSE 1 END WHERE id=?').run(req.params.id);if(!r.changes)return res.status(404).json({error:'Inbound not found'});res.json({ok:true})});
app.delete('/api/inbounds/:id',auth,(req,res)=>{const r=db.prepare('DELETE FROM inbounds WHERE id=?').run(req.params.id);if(!r.changes)return res.status(404).json({error:'Inbound not found'});res.json({ok:true})});

function clientRow(id){return db.prepare('SELECT c.*,i.tag inbound_tag,i.port,i.network,i.security,i.sni FROM clients c JOIN inbounds i ON i.id=c.inbound_id WHERE c.id=?').get(id)}
app.get('/api/clients',auth,(req,res)=>{
  const q=validateText(req.query.q,'query',100), status=String(req.query.status||''); let sql='SELECT c.*,i.tag inbound_tag,i.port,i.network,i.security,i.sni,(SELECT (up_bytes+down_bytes) FROM traffic_samples t WHERE t.client_id=c.id ORDER BY t.ts DESC LIMIT 1) used_bytes FROM clients c JOIN inbounds i ON i.id=c.inbound_id WHERE 1=1'; const args=[];
  if(q){sql+=' AND (c.name LIKE ? OR c.email LIKE ? OR c.uuid LIKE ? OR i.tag LIKE ?)';const z='%'+q+'%';args.push(z,z,z,z)}
  if(status==='enabled')sql+=' AND c.enabled=1'; if(status==='disabled')sql+=' AND c.enabled=0'; if(status==='expired'){sql+=' AND c.expiry>0 AND c.expiry<?';args.push(Math.floor(Date.now()/1000));} if(status==='quota'){sql+=' AND c.quota_bytes>0 AND EXISTS (SELECT 1 FROM traffic_samples t WHERE t.client_id=c.id AND (t.up_bytes+t.down_bytes)>=c.quota_bytes)';}
  sql+=' ORDER BY c.id DESC'; res.json(db.prepare(sql).all(...args));
});
app.post('/api/clients',auth,(req,res)=>{
  try{const b=req.body||{};const inbound_id=positiveInt(b.inbound_id,'inbound_id',1,2147483647,null);if(!db.prepare('SELECT id FROM inbounds WHERE id=?').get(inbound_id))return res.status(400).json({error:'Inbound not found'});const name=validateText(b.name,'name',100,true),email=validateText(b.email,'email',160),flow=validateText(b.flow,'flow',80),uuid=b.uuid?String(b.uuid).trim():uuidv4();if(!uuidValidate(uuid))return res.status(400).json({error:'invalid UUID'});const expiry=positiveInt(b.expiry,'expiry',0,4102444800,0),quota=positiveInt(b.quota_bytes,'quota_bytes',0,Number.MAX_SAFE_INTEGER,0);const portalToken=newPortalToken();const r=db.prepare('INSERT INTO clients(inbound_id,name,uuid,flow,email,expiry,quota_bytes,enabled,portal_token) VALUES(?,?,?,?,?,?,?,?,?)').run(inbound_id,name,uuid,flow,email,expiry,quota,b.enabled===false?0:1,portalToken);audit(req,'client.create',name);res.json({id:r.lastInsertRowid,uuid,portal_token:portalToken});}catch(e){res.status(400).json({error:e.message})}
});
app.put('/api/clients/:id',auth,(req,res)=>{
  try{const old=db.prepare('SELECT * FROM clients WHERE id=?').get(req.params.id);if(!old)return res.status(404).json({error:'Client not found'});const b=req.body||{},inboundId=positiveInt(b.inbound_id,'inbound_id',1,2147483647,old.inbound_id);if(!db.prepare('SELECT id FROM inbounds WHERE id=?').get(inboundId))return res.status(400).json({error:'Inbound not found'});const name=validateText(b.name??old.name,'name',100,true),email=validateText(b.email??old.email,'email',160),flow=validateText(b.flow??old.flow,'flow',80),uuid=String(b.uuid??old.uuid).trim();if(!uuidValidate(uuid))return res.status(400).json({error:'invalid UUID'});const expiry=positiveInt(b.expiry,'expiry',0,4102444800,old.expiry),quota=positiveInt(b.quota_bytes,'quota_bytes',0,Number.MAX_SAFE_INTEGER,old.quota_bytes);db.prepare('UPDATE clients SET inbound_id=?,name=?,uuid=?,flow=?,email=?,expiry=?,quota_bytes=?,enabled=? WHERE id=?').run(inboundId,name,uuid,flow,email,expiry,quota,b.enabled===false?0:(b.enabled===true?1:old.enabled),req.params.id);audit(req,'client.update',String(req.params.id));res.json({ok:true});}catch(e){res.status(400).json({error:e.message})}
});
app.patch('/api/clients/:id/toggle',auth,(req,res)=>{const r=db.prepare('UPDATE clients SET enabled=CASE enabled WHEN 1 THEN 0 ELSE 1 END WHERE id=?').run(req.params.id);if(!r.changes)return res.status(404).json({error:'Client not found'});audit(req,'client.toggle',String(req.params.id));res.json({ok:true})});
app.delete('/api/clients/:id',auth,(req,res)=>{const r=db.prepare('DELETE FROM clients WHERE id=?').run(req.params.id);if(!r.changes)return res.status(404).json({error:'Client not found'});audit(req,'client.delete',String(req.params.id));res.json({ok:true})});
app.post('/api/clients/disable-expired',auth,(req,res)=>{const now=Math.floor(Date.now()/1000);const r=db.prepare('UPDATE clients SET enabled=0 WHERE expiry>0 AND expiry<? AND enabled=1').run(now);res.json({ok:true,disabled:r.changes})});
app.post('/api/clients/disable-quota',auth,(req,res)=>{const r=db.prepare(`UPDATE clients SET enabled=0 WHERE enabled=1 AND quota_bytes>0 AND id IN (SELECT client_id FROM traffic_samples GROUP BY client_id HAVING MAX(up_bytes+down_bytes)>=clients.quota_bytes)`).run();res.json({ok:true,disabled:r.changes})});
app.post('/api/clients/:id/vless',auth,async(req,res)=>{const c=clientRow(req.params.id);if(!c)return res.status(404).json({error:'Client not found'});const host=validateText(req.body?.host||setting('server_host','localhost'),'host',255,true);const params=new URLSearchParams({encryption:'none'});if(c.flow)params.set('flow',c.flow);if(c.security==='tls'){params.set('security','tls');params.set('sni',c.sni||host)}else params.set('security',c.security||'none');if(c.network&&c.network!=='tcp')params.set('type',c.network);const link=`vless://${c.uuid}@${host}:${c.port}?${params.toString()}#${encodeURIComponent(c.name)}`;const qr=await QRCode.toDataURL(link);res.json({link,qr})});

app.get('/api/clients/:id/traffic',auth,(req,res)=>{const id=Number(req.params.id),c=clientRow(id);if(!c)return res.status(404).json({error:'Client not found'});const since=Math.floor(Date.now()/1000)-7*86400;const history=db.prepare('SELECT ts,up_bytes,down_bytes,online FROM traffic_samples WHERE client_id=? AND ts>=? ORDER BY ts').all(id,since);const last=history[history.length-1];res.json({client:{...c,current_up:last?.up_bytes||0,current_down:last?.down_bytes||0,used_bytes:(last?.up_bytes||0)+(last?.down_bytes||0)},history})});

app.post('/api/clients/:id/portal-token',auth,(req,res)=>{
  const id=Number(req.params.id); const c=db.prepare('SELECT id,name FROM clients WHERE id=?').get(id);
  if(!c) return res.status(404).json({error:'Client not found'});
  const token=newPortalToken(); db.prepare('UPDATE clients SET portal_token=? WHERE id=?').run(token,id); audit(req,'client.portal_token.rotate',String(id));
  res.json({ok:true,token});
});
app.get('/api/portal/:token',async(req,res)=>{
  const token=String(req.params.token||''); if(token.length<20 || token.length>100) return res.status(404).json({error:'Not found'});
  const c=db.prepare('SELECT c.*,i.tag inbound_tag,i.port,i.network,i.security,i.sni FROM clients c JOIN inbounds i ON i.id=c.inbound_id WHERE c.portal_token=?').get(token);
  if(!c) return res.status(404).json({error:'Not found'});
  const host=setting('server_host','localhost'); const params=new URLSearchParams({encryption:'none'}); if(c.flow)params.set('flow',c.flow); if(c.security==='tls'){params.set('security','tls');params.set('sni',c.sni||host)} else params.set('security',c.security||'none'); if(c.network&&c.network!=='tcp')params.set('type',c.network);
  const link=`vless://${c.uuid}@${host}:${c.port}?${params.toString()}#${encodeURIComponent(c.name)}`; const qr=await QRCode.toDataURL(link);
  const last=db.prepare('SELECT ts,up_bytes,down_bytes,online FROM traffic_samples WHERE client_id=? ORDER BY ts DESC LIMIT 1').get(c.id);
  res.json({name:c.name,inbound:c.inbound_tag,enabled:!!c.enabled,expiry:c.expiry,quota_bytes:c.quota_bytes,used_bytes:(last?.up_bytes||0)+(last?.down_bytes||0),online:!!last?.online,link,qr,serverTime:new Date().toISOString()});
});
app.get('/portal', (req,res)=>res.sendFile(path.resolve('public/portal.html')));

app.get('/api/settings',auth,(req,res)=>res.json({server_host:setting('server_host',''),xray_config:setting('xray_config','/etc/xray/config.json'),xray_binary:setting('xray_binary','xray'),xray_api:setting('xray_api','127.0.0.1:10085'),alert_webhook:setting('alert_webhook','')}));
app.put('/api/settings',auth,(req,res)=>{for(const[k,v]of Object.entries(req.body||{})){if(['server_host','xray_config','xray_binary','xray_api','alert_webhook'].includes(k)){const s=validateText(v,k,255);db.prepare('INSERT INTO settings(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value').run(k,s)}}res.json({ok:true})});

const xrayBinary=()=>setting('xray_binary','xray');
const xrayApiServer=()=>setting('xray_api','127.0.0.1:10085');
function runXrayStats(){return new Promise((resolve,reject)=>execFile(xrayBinary(),['api','statsquery','--server='+xrayApiServer()],{timeout:7000,maxBuffer:4*1024*1024},(err,stdout,stderr)=>{if(err)return reject(new Error((stderr||err.message||'Xray stats query failed').trim()));let raw=String(stdout||'').trim();try{return resolve(JSON.parse(raw))}catch{}const s=raw.indexOf('{'),e=raw.lastIndexOf('}');if(s>=0&&e>s){try{return resolve(JSON.parse(raw.slice(s,e+1)))}catch{}}reject(new Error('Xray stats output was not JSON'))}))}
function extractStats(payload){const arr=Array.isArray(payload?.stat)?payload.stat:Array.isArray(payload?.stats)?payload.stats:[];const out=new Map();for(const st of arr){const name=String(st?.name||''),value=Number(st?.value||0);const m=name.match(/^user>>>([^>]+)>>>traffic>>>(uplink|downlink)$/i);if(m){const row=out.get(m[1])||{up:0,down:0};row[m[2].toLowerCase()==='uplink'?'up':'down']=Number.isFinite(value)?value:0;out.set(m[1],row)}}return out}
async function collectTraffic(){const clients=db.prepare('SELECT id,name,email,uuid,enabled,expiry,quota_bytes FROM clients').all();let stats;try{stats=extractStats(await runXrayStats())}catch(e){return{available:false,error:e.message,clients:[]}}const now=Math.floor(Date.now()/1000),rows=[];const insert=db.prepare('INSERT INTO traffic_samples(client_id,ts,up_bytes,down_bytes,online) VALUES(?,?,?,?,?)');const tx=db.transaction(()=>{for(const c of clients){const key=c.email||c.name,v=stats.get(key)||{up:0,down:0},prev=db.prepare('SELECT up_bytes,down_bytes,ts FROM traffic_samples WHERE client_id=? ORDER BY ts DESC LIMIT 1').get(c.id),active=!!prev&&((v.up>prev.up_bytes)||(v.down>prev.down_bytes))&&now-prev.ts<=180;insert.run(c.id,now,v.up,v.down,active?1:0);const used=v.up+v.down;rows.push({id:c.id,name:c.name,email:c.email,up_bytes:v.up,down_bytes:v.down,used_bytes:used,online:active,expiry:c.expiry,quota_bytes:c.quota_bytes,enabled:c.enabled,quota_exceeded:c.quota_bytes>0&&used>=c.quota_bytes});}});tx();return{available:true,serverTime:new Date().toISOString(),clients:rows}}
app.get('/api/traffic',auth,async(req,res)=>{try{const j=await collectTraffic();if(j.available){const since=Math.floor(Date.now()/1000)-86400;j.history=db.prepare('SELECT ts,SUM(up_bytes) up_bytes,SUM(down_bytes) down_bytes,SUM(online) online FROM traffic_samples WHERE ts>=? GROUP BY ts ORDER BY ts').all(since)}res.json(j)}catch(e){res.status(500).json({available:false,error:e.message})}});

function buildXrayConfig(){const inbounds=db.prepare('SELECT * FROM inbounds WHERE enabled=1 ORDER BY id').all();return{log:{loglevel:'warning'},api:{services:['StatsService'],tag:'api'},stats:{},policy:{levels:{0:{statsUserUplink:true,statsUserDownlink:true}},system:{statsInboundUplink:true,statsInboundDownlink:true}},inbounds:[{tag:'api',listen:'127.0.0.1',port:10085,protocol:'dokodemo-door',settings:{address:'127.0.0.1'}},...inbounds.map(i=>({tag:i.tag,port:Number(i.port),listen:'0.0.0.0',protocol:i.protocol,settings:{clients:db.prepare('SELECT uuid,email,name,flow FROM clients WHERE inbound_id=? AND enabled=1').all(i.id).map(c=>({id:c.uuid,email:c.email||c.name,flow:c.flow||undefined})).map(x=>{Object.keys(x).forEach(k=>x[k]===undefined&&delete x[k]);return x}),decryption:i.protocol==='vless'?'none':undefined},streamSettings:{network:i.network||'tcp',security:i.security||'none',...(i.security==='tls'&&i.sni?{tlsSettings:{serverName:i.sni}}:{})}}))],routing:{rules:[{type:'field',inboundTag:['api'],outboundTag:'api'}]},outbounds:[{protocol:'freedom',tag:'direct'},{protocol:'blackhole',tag:'blocked'},{protocol:'blackhole',tag:'api'}]}}
app.get('/api/server/metrics',auth,(req,res)=>{
  const mem=process.memoryUsage(); const total=os.totalmem(); const free=os.freemem(); const load=os.loadavg();
  let disk=null; try { const st=fs.statfsSync(process.cwd()); disk={free_bytes:Number(st.bfree)*Number(st.bsize),total_bytes:Number(st.blocks)*Number(st.bsize)}; } catch {}
  res.json({uptime:os.uptime(),node_uptime:process.uptime(),cpu_cores:os.cpus().length,load_1m:load[0],load_5m:load[1],load_15m:load[2],memory:{total_bytes:total,free_bytes:free,used_bytes:total-free,process_rss:mem.rss,process_heap:mem.heapUsed},disk,hostname:os.hostname(),platform:os.platform(),serverTime:new Date().toISOString()});
});
app.get('/api/traffic/history',auth,(req,res)=>{
  const hours=Math.min(168,Math.max(1,Number(req.query.hours)||24)); const since=Math.floor(Date.now()/1000)-hours*3600;
  const rows=db.prepare(`SELECT (ts/300)*300 bucket,SUM(up_bytes) up_bytes,SUM(down_bytes) down_bytes,SUM(online) online FROM traffic_samples WHERE ts>=? GROUP BY bucket ORDER BY bucket`).all(since);
  res.json({hours,rows});
});
app.get('/api/audit',auth,(req,res)=>res.json(db.prepare('SELECT a.id,a.action,a.details,a.ts,u.username FROM audit_log a LEFT JOIN users u ON u.id=a.user_id ORDER BY a.id DESC LIMIT 100').all()));

app.get('/api/xray/config',auth,(req,res)=>res.json(buildXrayConfig()));
app.post('/api/xray/apply',auth,(req,res)=>{const cfgPath=setting('xray_config','/etc/xray/config.json');try{const cfg=buildXrayConfig(),dir=path.dirname(cfgPath);fs.mkdirSync(dir,{recursive:true});if(fs.existsSync(cfgPath))fs.copyFileSync(cfgPath,cfgPath+'.bak-'+Date.now());const tmp=cfgPath+'.tmp';fs.writeFileSync(tmp,JSON.stringify(cfg,null,2));execFile(xrayBinary(),['run','-test','-config',tmp],{timeout:10000},(e,stdout,stderr)=>{if(e){try{fs.unlinkSync(tmp)}catch{};return res.status(400).json({error:'Xray config test failed',details:(stderr||stdout||e.message).trim()})}fs.renameSync(tmp,cfgPath);res.json({ok:true,path:cfgPath})})}catch(e){res.status(500).json({error:e.message})}});
app.post('/api/tools/restart-xray',auth,(req,res)=>execFile('systemctl',['restart','xray'],{timeout:15000},e=>e?res.status(500).json({error:e.message}):res.json({ok:true})));
app.post('/api/tools/test-xray',auth,(req,res)=>execFile('systemctl',['is-active','xray'],{timeout:5000},(e,stdout)=>res.json({active:!e&&stdout.trim()==='active',status:stdout.trim()||'unknown'})));



function currentUsageRows() {
  const rows = db.prepare(`SELECT c.id,c.name,c.email,c.expiry,c.quota_bytes,c.enabled,
    COALESCE((SELECT up_bytes FROM traffic_samples t WHERE t.client_id=c.id ORDER BY t.ts DESC LIMIT 1),0) up_bytes,
    COALESCE((SELECT down_bytes FROM traffic_samples t WHERE t.client_id=c.id ORDER BY t.ts DESC LIMIT 1),0) down_bytes
    FROM clients c`).all();
  return rows.map(r => ({...r, used_bytes:Number(r.up_bytes||0)+Number(r.down_bytes||0), quota_exceeded:Number(r.quota_bytes||0)>0 && Number(r.up_bytes||0)+Number(r.down_bytes||0)>=Number(r.quota_bytes)}));
}
function createAlert(kind, clientId, message) {
  const recent = db.prepare('SELECT id FROM alerts WHERE kind=? AND client_id IS ? AND message=? AND created_at>?').get(kind, clientId ?? null, message, Math.floor(Date.now()/1000)-86400);
  if (!recent) db.prepare('INSERT INTO alerts(kind,client_id,message,created_at) VALUES(?,?,?,?)').run(kind,clientId ?? null,message,Math.floor(Date.now()/1000));
}
async function sendWebhook(message) {
  const url=setting('alert_webhook','');
  if(!url) return;
  try { const u=new URL(url); if(!['http:','https:'].includes(u.protocol)) return; await fetch(u,{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({text:message,source:'analyser-panel',timestamp:new Date().toISOString()})}); } catch {}
}
function runLifecycle() {
  const now=Math.floor(Date.now()/1000);
  const expired=db.prepare('SELECT id,name FROM clients WHERE enabled=1 AND expiry>0 AND expiry<?').all(now);
  for(const c of expired){ db.prepare('UPDATE clients SET enabled=0 WHERE id=?').run(c.id); createAlert('expired',c.id,`Client ${c.name} expired and was disabled.`); }
  for(const c of currentUsageRows().filter(x=>x.enabled && x.quota_exceeded)){ db.prepare('UPDATE clients SET enabled=0 WHERE id=?').run(c.id); createAlert('quota',c.id,`Client ${c.name} reached its traffic quota and was disabled.`); }
  for(const c of expired) void sendWebhook(`Analyser: client ${c.name} expired and was disabled.`);
}
function rollupUsage() {
  const now=Math.floor(Date.now()/1000); const since=now-36*3600;
  const rows=db.prepare('SELECT client_id,ts,up_bytes,down_bytes FROM traffic_samples WHERE ts>=?').all(since);
  const dayStmt=db.prepare(`INSERT INTO usage_daily(client_id,day,up_bytes,down_bytes) VALUES(?,?,?,?) ON CONFLICT(client_id,day) DO UPDATE SET up_bytes=excluded.up_bytes,down_bytes=excluded.down_bytes`);
  const monthStmt=db.prepare(`INSERT INTO usage_monthly(client_id,month,up_bytes,down_bytes) VALUES(?,?,?,?) ON CONFLICT(client_id,month) DO UPDATE SET up_bytes=excluded.up_bytes,down_bytes=excluded.down_bytes`);
  const tx=db.transaction(()=>{ for(const r of rows){ const d=new Date(r.ts*1000); const day=d.toISOString().slice(0,10), month=day.slice(0,7); dayStmt.run(r.client_id,day,r.up_bytes||0,r.down_bytes||0); monthStmt.run(r.client_id,month,r.up_bytes||0,r.down_bytes||0); }}); tx();
}
setInterval(()=>{ try{runLifecycle();rollupUsage()}catch(e){console.error('lifecycle:',e.message)} }, 60_000);
setTimeout(()=>{try{runLifecycle();rollupUsage()}catch{}}, 2_000);

app.get('/api/usage/daily',auth,(req,res)=>{
  const days=Math.min(90,Math.max(1,Number(req.query.days)||30));
  const since=new Date(Date.now()-days*86400000).toISOString().slice(0,10);
  res.json(db.prepare(`SELECT d.day,SUM(d.up_bytes) up_bytes,SUM(d.down_bytes) down_bytes FROM usage_daily d WHERE d.day>=? GROUP BY d.day ORDER BY d.day`).all(since));
});
app.get('/api/usage/monthly',auth,(req,res)=>res.json(db.prepare(`SELECT m.month,SUM(m.up_bytes) up_bytes,SUM(m.down_bytes) down_bytes FROM usage_monthly m GROUP BY m.month ORDER BY m.month DESC LIMIT 24`).all()));
app.get('/api/clients/:id/usage-summary',auth,(req,res)=>{
  const id=Number(req.params.id); if(!clientRow(id)) return res.status(404).json({error:'Client not found'});
  res.json({daily:db.prepare('SELECT day,up_bytes,down_bytes FROM usage_daily WHERE client_id=? ORDER BY day DESC LIMIT 90').all(id),monthly:db.prepare('SELECT month,up_bytes,down_bytes FROM usage_monthly WHERE client_id=? ORDER BY month DESC LIMIT 24').all(id)});
});
app.get('/api/alerts',auth,(req,res)=>res.json(db.prepare(`SELECT a.*,c.name client_name FROM alerts a LEFT JOIN clients c ON c.id=a.client_id ORDER BY a.id DESC LIMIT 100`).all()));
app.post('/api/alerts/:id/ack',auth,(req,res)=>{const r=db.prepare('UPDATE alerts SET acknowledged=1 WHERE id=?').run(Number(req.params.id));if(!r.changes)return res.status(404).json({error:'Alert not found'});res.json({ok:true})});
app.post('/api/alerts/ack-all',auth,(req,res)=>{db.prepare('UPDATE alerts SET acknowledged=1 WHERE acknowledged=0').run();res.json({ok:true})});

app.get('/api/backups',auth,(req,res)=>{
  const cfg=setting('xray_config','/etc/xray/config.json'); const dir=path.dirname(cfg); let files=[];
  try { files=fs.readdirSync(dir).filter(f=>f.startsWith(path.basename(cfg)+'.bak-')).map(f=>{const st=fs.statSync(path.join(dir,f));return{name:f,size:st.size,mtime:st.mtime.toISOString()}}).sort((a,b)=>b.mtime.localeCompare(a.mtime)).slice(0,20); } catch(e) {}
  res.json({config:cfg,backups:files});
});
app.post('/api/backups/create',auth,(req,res)=>{
  const cfg=setting('xray_config','/etc/xray/config.json'); try{if(!fs.existsSync(cfg))return res.status(404).json({error:'Xray config does not exist'});const out=cfg+'.bak-'+Date.now();fs.copyFileSync(cfg,out);audit(req,'xray.backup.create',out);res.json({ok:true,file:out})}catch(e){res.status(500).json({error:e.message})}
});
app.post('/api/backups/restore',auth,(req,res)=>{
  const cfg=setting('xray_config','/etc/xray/config.json'),name=validateText(req.body?.name,'name',255,true); if(path.basename(name)!==name || !name.startsWith(path.basename(cfg)+'.bak-')) return res.status(400).json({error:'Invalid backup name'});
  const file=path.join(path.dirname(cfg),name); try{if(!fs.existsSync(file))return res.status(404).json({error:'Backup not found'});const tmp=cfg+'.restore-'+Date.now();fs.copyFileSync(file,tmp);fs.renameSync(tmp,cfg);audit(req,'xray.backup.restore',name);res.json({ok:true})}catch(e){res.status(500).json({error:e.message})}
});

app.get('/api/health',auth,async(req,res)=>{
  let xray=false; try { const r=await new Promise(resolve=>execFile('systemctl',['is-active','xray'],{timeout:3000},(e,o)=>resolve({ok:!e&&String(o).trim()==='active'}))); xray=r.ok; } catch {}
  const pending=db.prepare('SELECT COUNT(*) n FROM alerts WHERE acknowledged=0').get().n;
  res.json({ok:true,xray,unacknowledged_alerts:pending,time:new Date().toISOString()});
});

app.listen(PORT,()=>console.log(`Analyser Panel v6 listening on :${PORT}`));
