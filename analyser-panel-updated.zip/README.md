# Analyser Panel

A small Node.js + SQLite admin panel for managing VLESS/Trojan inbounds and clients on a server you control.

## Run

```bash
npm install
ADMIN_PASSWORD='"'"'choose-a-strong-password'"'"' JWT_SECRET='"'"'replace-with-random-secret'"'"' npm start
```

Open `http://SERVER:3000`. Default username is `admin`. If `ADMIN_PASSWORD` is not supplied, the development fallback is `change-me-now`; change it before exposing the panel.

## Xray integration

Set **Server host** and **Xray config path** in Panel Settings. **Apply config** generates a minimal Xray configuration from enabled Analyser inbounds/clients, validates it with `xray run -test`, and keeps a timestamped backup of the previous config. Restarting Xray requires a systemd service named `xray` and sufficient OS permissions.

The generated configuration is intentionally minimal. Review it before production use, especially TLS certificates, WebSocket/gRPC transport settings, firewall rules, and service permissions.
