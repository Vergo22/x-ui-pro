import express from 'express';
import Database from 'better-sqlite3';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import QRCode from 'qrcode';
import { v4 as uuidv4 } from 'uuid';
import crypto from 'crypto';
import fs from 'fs';
import { execFile } from 'child_process';

const app=express(); const PORT=process.env.PORT||3000;
const SECRET=process.env.JWT_SECRET||crypto.randomBytes(32).toString('hex');
const db=new Database(process.env.DB_PATH||'analyser.db');
db.pragma('journal_mode=WAL');
db.exec(`CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY,username TEXT UNIQUE,password TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS settings(key TEXT PRIMARY KEY,value TEXT);
CREATE TABLE IF NOT EXISTS inbounds(id INTEGER PRIMARY KEY AUTOINCREMENT,tag TEXT UNIQUE,protocol TEXT DEFAULT 'vless',port INTEGER,network TEXT DEFAULT 'tcp',security TEXT DEFAULT 'none',sni TEXT DEFAULT '',enabled INTEGER DEFAULT 1,created_at TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS clients(id INTEGER PRIMARY KEY AUTOINCREMENT,inbound_id INTEGER,name TEXT,uuid TEXT UNIQUE,flow TEXT DEFAULT '',email TEXT DEFAULT '',expiry INTEGER DEFAULT 0,enabled INTEGER DEFAULT 1,created_at TEXT DEFAULT CURRENT_TIMESTAMP,FOREIGN KEY(inbound_id) REFERENCES inbounds(id) ON DELETE CASCADE);`);
if(!db.prepare('SELECT 1 FROM users LIMIT 1').get()) db.prepare('INSERT INTO users(username,password) VALUES(?,?)').run('admin',bcrypt.hashSync(process.env.ADMIN_PASSWORD||'change-me-now',12));
const setting=(k,d='')=>db.prepare('SELECT value FROM settings WHERE key=?').get(k)?.value??d;
const auth=(req,res,next)=>{try{const h=req.headers.authorization||''; if(!h.startsWith('Bearer ')) throw 0; req.user=jwt.verify(h.slice(7),SECRET); next()}catch{res.status(401).json({error:'Unauthorized'})}};
app.use(express.json()); app.use(express.static('public'));
app.post('/api/login',(req,res)=>{const u=db.prepare('SELECT * FROM users WHERE username=?').get(req.body.username); if(!u||!bcrypt.compareSync(req.body.password,u.password)) return res.status(401).json({error:'Invalid credentials'}); res.json({token:jwt.sign({id:u.id,username:u.username},SECRET,{expiresIn:'12h'})})});
app.get('/api/me',auth,(req,res)=>res.json(req.user));
app.get('/api/dashboard',auth,(req,res)=>{res.json({inbounds:db.prepare('SELECT COUNT(*) n FROM inbounds WHERE enabled=1').get().n,clients:db.prepare('SELECT COUNT(*) n FROM clients WHERE enabled=1').get().n,serverTime:new Date().toISOString()})});
app.get('/api/inbounds',auth,(req,res)=>res.json(db.prepare('SELECT * FROM inbounds ORDER BY id DESC').all()));
app.post('/api/inbounds',auth,(req,res)=>{const b=req.body; if(!b.tag||!b.port) return res.status(400).json({error:'tag and port required'}); try{const r=db.prepare('INSERT INTO inbounds(tag,protocol,port,network,security,sni,enabled) VALUES(?,?,?,?,?,?,?)').run(b.tag,b.protocol||'vless',Number(b.port),b.network||'tcp',b.security||'none',b.sni||'',b.enabled===false?0:1); res.json({id:r.lastInsertRowid})}catch(e){res.status(400).json({error:e.message})}});
app.delete('/api/inbounds/:id',auth,(req,res)=>{db.prepare('DELETE FROM clients WHERE inbound_id=?').run(req.params.id); db.prepare('DELETE FROM inbounds WHERE id=?').run(req.params.id); res.json({ok:true})});
app.get('/api/clients',auth,(req,res)=>res.json(db.prepare('SELECT c.*,i.tag inbound_tag,i.port,i.network,i.security,i.sni FROM clients c JOIN inbounds i ON i.id=c.inbound_id ORDER BY c.id DESC').all()));
app.post('/api/clients',auth,async(req,res)=>{const b=req.body; if(!b.inbound_id||!b.name) return res.status(400).json({error:'inbound_id and name required'}); const uuid=b.uuid||uuidv4(); try{const r=db.prepare('INSERT INTO clients(inbound_id,name,uuid,flow,email,expiry,enabled) VALUES(?,?,?,?,?,?,?)').run(b.inbound_id,b.name,uuid,b.flow||'',b.email||'',Number(b.expiry||0),b.enabled===false?0:1); res.json({id:r.lastInsertRowid,uuid})}catch(e){res.status(400).json({error:e.message})}});
app.delete('/api/clients/:id',auth,(req,res)=>{db.prepare('DELETE FROM clients WHERE id=?').run(req.params.id);res.json({ok:true})});
app.post('/api/clients/:id/vless',auth,async(req,res)=>{const c=db.prepare('SELECT c.*,i.* FROM clients c JOIN inbounds i ON i.id=c.inbound_id WHERE c.id=?').get(req.params.id); if(!c)return res.status(404).json({error:'Client not found'}); const host=req.body.host||setting('server_host','localhost'); const params=new URLSearchParams(); params.set('encryption','none'); if(c.flow)params.set('flow',c.flow); const security=c.security||'none'; if(security==='tls'){params.set('security','tls');if(c.sni||c.sni)params.set('sni',c.sni||host)} else params.set('security',security); if(c.network&&c.network!=='tcp')params.set('type',c.network); const link=`vless://${c.uuid}@${host}:${c.port}?${params.toString()}#${encodeURIComponent(c.name)}`; const qr=await QRCode.toDataURL(link); res.json({link,qr})});
app.get('/api/settings',auth,(req,res)=>res.json({server_host:setting('server_host',''),xray_config:setting('xray_config','/etc/xray/config.json')}));
app.put('/api/settings',auth,(req,res)=>{for(const [k,v] of Object.entries(req.body)){if(['server_host','xray_config'].includes(k))db.prepare('INSERT INTO settings(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value').run(k,String(v))}res.json({ok:true})});

function buildXrayConfig(){
  const inbounds=db.prepare('SELECT * FROM inbounds WHERE enabled=1 ORDER BY id').all();
  return {
    log:{loglevel:'warning'},
    inbounds:inbounds.map(i=>({
      tag:i.tag, port:Number(i.port), listen:'0.0.0.0', protocol:i.protocol,
      settings:{clients:db.prepare('SELECT uuid,email,flow FROM clients WHERE inbound_id=? AND enabled=1').all(i.id).map(c=>({id:c.uuid,email:c.email||undefined,flow:c.flow||undefined})).map(x=>{Object.keys(x).forEach(k=>x[k]===undefined&&delete x[k]);return x}),decryption:i.protocol==='vless'?'none':undefined},
      streamSettings:{network:i.network||'tcp',security:i.security||'none',...(i.security==='tls'&&i.sni?{tlsSettings:{serverName:i.sni}}:{})}
    })),
    outbounds:[{protocol:'freedom',tag:'direct'},{protocol:'blackhole',tag:'blocked'}]
  };
}
app.get('/api/xray/config',auth,(req,res)=>res.json(buildXrayConfig()));
app.post('/api/xray/apply',auth,(req,res)=>{
  const path=setting('xray_config','/etc/xray/config.json');
  try{
    const cfg=buildXrayConfig(); const dir=require('path').dirname(path); fs.mkdirSync(dir,{recursive:true});
    if(fs.existsSync(path)) fs.copyFileSync(path,path+'.bak-'+Date.now());
    const tmp=path+'.tmp'; fs.writeFileSync(tmp,JSON.stringify(cfg,null,2));
    fs.renameSync(tmp,path);
    execFile('xray',['run','-test','-config',path],{timeout:10000},(e,stdout,stderr)=>{
      if(e) return res.status(400).json({error:'Xray config test failed',details:(stderr||stdout||e.message).trim()});
      res.json({ok:true,path});
    });
  }catch(e){res.status(500).json({error:e.message})}
});

app.post('/api/tools/restart-xray',auth,(req,res)=>{execFile('systemctl',['restart','xray'],{timeout:15000},e=>e?res.status(500).json({error:e.message}):res.json({ok:true}))});
app.post('/api/tools/test-xray',auth,(req,res)=>{execFile('systemctl',['is-active','xray'],{timeout:5000},(e,stdout)=>res.json({active:!e&&stdout.trim()==='active',status:stdout.trim()||'unknown'}))});
app.listen(PORT,()=>console.log(`Analyser Panel listening on :${PORT}`));
