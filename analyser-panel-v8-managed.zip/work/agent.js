import express from 'express';
import os from 'os';
import { execFile } from 'child_process';
const app=express(),PORT=Number(process.env.ANALYSER_AGENT_PORT||8787),TOKEN=process.env.ANALYSER_AGENT_TOKEN||'';
if(!TOKEN)throw new Error('ANALYSER_AGENT_TOKEN is required');app.disable('x-powered-by');app.use(express.json({limit:'32kb'}));
function auth(req,res,next){if(String(req.headers.authorization||'')!==`Bearer ${TOKEN}`)return res.status(401).json({error:'Unauthorized'});next()}
app.use((req,res,next)=>{res.setHeader('X-Content-Type-Options','nosniff');res.setHeader('X-Frame-Options','DENY');next()});
app.get('/health',(req,res)=>res.json({ok:true,service:'analyser-agent',hostname:os.hostname(),time:new Date().toISOString()}));
app.get('/metrics',auth,(req,res)=>{const total=os.totalmem(),free=os.freemem();res.json({hostname:os.hostname(),platform:process.platform,uptime:os.uptime(),cpu_cores:os.cpus().length,load_1m:os.loadavg()[0],memory:{total_bytes:total,free_bytes:free,used_bytes:total-free},time:new Date().toISOString()})});
function cmd(command,args,timeout=7000){return new Promise((resolve,reject)=>execFile(command,args,{timeout},(e,stdout,stderr)=>e?reject(new Error((stderr||stdout||e.message).trim())):resolve(stdout.trim())))}
app.get('/xray/status',auth,async(req,res)=>{try{const out=await cmd('systemctl',['is-active','xray']);res.json({active:out==='active',status:out||'unknown'})}catch(e){res.json({active:false,status:'unknown',error:e.message})}});
app.post('/xray/restart',auth,async(req,res)=>{try{await cmd('systemctl',['restart','xray'],15000);const out=await cmd('systemctl',['is-active','xray']);res.json({ok:out==='active',status:out})}catch(e){res.status(500).json({error:e.message})}});
app.listen(PORT,'127.0.0.1',()=>console.log(`Analyser agent listening on 127.0.0.1:${PORT}`));
