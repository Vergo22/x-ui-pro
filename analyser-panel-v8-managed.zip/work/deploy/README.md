# Analyser v7 deployment

This package turns the Analyser project into a browser-accessible management website on a Linux server. It is designed to run on the same host as the Xray service so the existing local Xray management functions continue to work.

## Recommended architecture

Browser → HTTPS/Nginx → Analyser (127.0.0.1:3000) → local Xray service/API

Keep the Xray API bound to localhost. Do not expose port 10085 publicly.

## Ubuntu/Debian

1. Install Node.js 20+ and Xray.
2. Point your DNS record (for example `panel.example.com`) to the server.
3. Run from the project directory:

```bash
sudo ./deploy/install-ubuntu.sh panel.example.com
```

The installer creates the `analyser` service and stores secrets in `/etc/analyser/analyser.env`.

4. Verify:

```bash
curl http://127.0.0.1:3000/healthz
systemctl status analyser
```

5. Add HTTPS using your preferred ACME client. With Certbot + Nginx:

```bash
sudo apt-get install -y certbot python3-certbot-nginx
sudo certbot --nginx -d panel.example.com
```

## DNS

Create an A record for your panel hostname pointing to the server's public IP. If you use an AAAA record, make sure IPv6 is actually configured and reachable.

## Xray settings

After logging in, open **Settings** and set:
- Server host: the public hostname clients should use
- Xray config path: normally `/etc/xray/config.json`
- Xray binary: normally `xray`
- Xray API: `127.0.0.1:10085`

The Xray API should remain localhost-only.

## Firewall

Only expose the ports you actually need, normally SSH, HTTP/HTTPS, and your configured Xray inbound ports. Do not expose the panel's port 3000 or Xray's API port 10085 to the public internet.

## Important

This build manages the local Xray instance on the host where Analyser runs. It is not a multi-server control plane yet. A later multi-server architecture should use authenticated agents rather than exposing Xray's local API directly.
