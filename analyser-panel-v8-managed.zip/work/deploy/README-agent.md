# Analyser Agent
Install `agent.js` on each server you want the central panel to manage. It exposes health/metrics and authenticated Xray status/restart operations. It binds to `127.0.0.1` by default; use a private network/VPN or HTTPS reverse proxy for remote access. Do not expose an unauthenticated agent publicly.

Example:
```bash
mkdir -p /opt/analyser-agent
cp agent.js package.json /opt/analyser-agent/
cp deploy/agent.env.example /etc/analyser-agent.env
chmod 600 /etc/analyser-agent.env
# edit /etc/analyser-agent.env and set a long random token
cp deploy/analyser-agent.service /etc/systemd/system/
systemctl daemon-reload
systemctl enable --now analyser-agent
```
Then in Analyser > Servers, enter the agent URL and matching token.
