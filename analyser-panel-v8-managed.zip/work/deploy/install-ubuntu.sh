#!/usr/bin/env bash
set -euo pipefail

DOMAIN="${1:-}"
if [[ -z "$DOMAIN" ]]; then
  echo "Usage: sudo ./deploy/install-ubuntu.sh panel.example.com"
  exit 1
fi

if [[ $EUID -ne 0 ]]; then echo "Run as root."; exit 1; fi
command -v node >/dev/null || { echo "Node.js is required. Install Node.js 20+ first."; exit 1; }
node -e 'const major=+process.versions.node.split(".")[0]; if(major<20) process.exit(1)' || { echo "Node.js 20+ required."; exit 1; }
command -v nginx >/dev/null || apt-get update && apt-get install -y nginx

id analyser >/dev/null 2>&1 || useradd --system --home /opt/analyser --shell /usr/sbin/nologin analyser
mkdir -p /opt/analyser /var/lib/analyser /etc/analyser
cp -a . /opt/analyser/
chown -R analyser:analyser /opt/analyser /var/lib/analyser
chmod 750 /etc/analyser

if [[ ! -f /etc/analyser/analyser.env ]]; then
  SECRET=$(node -e 'console.log(require("crypto").randomBytes(48).toString("base64url"))')
  PASS=$(node -e 'console.log(require("crypto").randomBytes(18).toString("base64url"))')
  cat >/etc/analyser/analyser.env <<ENV
NODE_ENV=production
PORT=3000
JWT_SECRET=$SECRET
ADMIN_PASSWORD=$PASS
DB_PATH=/var/lib/analyser/analyser.db
ENV
  chmod 600 /etc/analyser/analyser.env
  echo "Generated credentials in /etc/analyser/analyser.env"
fi

cd /opt/analyser
sudo -u analyser npm install --omit=dev
cp deploy/analyser.service /etc/systemd/system/analyser.service
sed "s/PANEL_DOMAIN/$DOMAIN/g" deploy/nginx.conf.template >/etc/nginx/sites-available/analyser
ln -sf /etc/nginx/sites-available/analyser /etc/nginx/sites-enabled/analyser
rm -f /etc/nginx/sites-enabled/default
nginx -t
systemctl daemon-reload
systemctl enable --now analyser
systemctl reload nginx

echo
systemctl --no-pager --full status analyser || true
echo
printf 'Panel HTTP endpoint: http://%s\n' "$DOMAIN"
printf 'Next: point DNS A/AAAA record to this server, then enable HTTPS with certbot.\n'
