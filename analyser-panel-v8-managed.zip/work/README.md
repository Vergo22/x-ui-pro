# Analyser Panel v7

Browser-based web management panel for a local Xray server.

## What this release adds
- Production deployment files for Linux + Nginx + systemd
- `/healthz` health endpoint
- `/api/version` authenticated version endpoint
- Reverse-proxy-aware Express configuration
- Persistent database path via environment configuration
- Hardened systemd service unit
- Ubuntu/Debian installation helper
- HTTPS deployment guide

## Existing features
- Authentication with HttpOnly JWT cookie and login rate limiting
- Inbound/client CRUD, expiry and quota controls
- VLESS links and QR codes
- Xray config generation, validation, backup and apply
- Live telemetry and usage rollups
- Automatic expiry/quota lifecycle enforcement
- Alerts, audit log and client portal
- Server metrics and Xray management

## Quick deployment

```bash
sudo ./deploy/install-ubuntu.sh panel.example.com
```

Read `deploy/README.md` before exposing the panel publicly.

## Production environment
- `NODE_ENV=production`
- `JWT_SECRET` — long random secret
- `ADMIN_PASSWORD` — initial admin password
- `PORT` — normally 3000
- `DB_PATH` — persistent SQLite database path

Do not expose the Analyser port or Xray API directly to the public internet; put the panel behind HTTPS and keep Xray API localhost-only.


## v8 Managed Servers
Register remote Analyser Agents under Servers.
